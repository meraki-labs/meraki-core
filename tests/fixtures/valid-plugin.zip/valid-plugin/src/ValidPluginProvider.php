<?php
namespace TestOrg\ValidPlugin;
class ValidPluginProvider {}
